    package src.Employee;  
      
    public class Employee {  
     
	private String Dojinmonths;
	private String FirstName;
	private String LastName;
	private String Email;
	private int EmployeeId;
	private long PhoneNumber;
	private long Salary;
      

	  
    public String getDojinmonths() {  
        return Dojinmonths;  
    }  
      
    public void setDojinmonths(String Dojinmonths) {  
        this.Dojinmonths = Dojinmonths;  
    }  
      
    public String getFirstName() {  
        return FirstName;  
    }  
      
    public void setFirstName(String FirstName) {  
        this.FirstName = FirstName;  
    } 

	public String getLastName() {  
        return LastName;  
    }  
      
    public void setLastName(String LastName) {  
        this.LastName = LastName;  
    } 

	public String getEmail() {  
        return Email;  
    }  
      
    public void setEmail(String Email) {  
        this.Email = Email;  
    } 	
	
	public int getEmployeeId() {  
        return EmployeeId;  
    }  
      
    public void setEmployeeId(int EmployeeId) {  
        this.EmployeeId = EmployeeId; 
		
		
		public long getPhoneNumber() {  
        return PhoneNumber;  
    }  
      
    public void setPhoneNumber(long PhoneNumber) {  
        this.PhoneNumber = PhoneNumber; 
		
		
		public long getSalary() {  
        return Salary;  
    }  
      
    public void setSalary(long Salary) {  
        this.Salary = Salary; }
		
		
		
    public void print(){  
        System.out.println();  
    } 
	
    }  


